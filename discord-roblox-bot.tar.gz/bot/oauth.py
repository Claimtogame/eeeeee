import aiohttp
import urllib.parse
import secrets
import logging
from typing import Optional, Dict, Any
from config import Config

logger = logging.getLogger(__name__)

class RobloxOAuth:
    def __init__(self):
        self.client_id = Config.ROBLOX_CLIENT_ID
        self.client_secret = Config.ROBLOX_CLIENT_SECRET
        self.redirect_uri = Config.ROBLOX_REDIRECT_URI
        
    def generate_oauth_url(self, state: str) -> str:
        """Generate OAuth authorization URL"""
        params = {
            'client_id': self.client_id,
            'redirect_uri': self.redirect_uri,
            'response_type': 'code',
            'scope': 'openid profile',
            'state': state
        }
        
        return f"{Config.ROBLOX_OAUTH_URL}?{urllib.parse.urlencode(params)}"
        
    async def exchange_code_for_token(self, code: str) -> Optional[Dict[str, Any]]:
        """Exchange authorization code for access token"""
        try:
            data = {
                'grant_type': 'authorization_code',
                'code': code,
                'redirect_uri': self.redirect_uri,
                'client_id': self.client_id,
                'client_secret': self.client_secret
            }
            
            async with aiohttp.ClientSession() as session:
                async with session.post(Config.ROBLOX_TOKEN_URL, data=data) as response:
                    if response.status == 200:
                        token_data = await response.json()
                        logger.info("Successfully exchanged code for token")
                        return token_data
                    else:
                        error_text = await response.text()
                        logger.error(f"Token exchange failed: {response.status} - {error_text}")
                        return None
                        
        except Exception as e:
            logger.error(f"Error during token exchange: {e}")
            return None
            
    async def get_user_info(self, access_token: str) -> Optional[Dict[str, Any]]:
        """Get user information using access token"""
        try:
            headers = {
                'Authorization': f'Bearer {access_token}',
                'Content-Type': 'application/json'
            }
            
            async with aiohttp.ClientSession() as session:
                async with session.get(Config.ROBLOX_USER_INFO_URL, headers=headers) as response:
                    if response.status == 200:
                        user_data = await response.json()
                        logger.info(f"Retrieved user info for user ID: {user_data.get('sub')}")
                        return user_data
                    else:
                        error_text = await response.text()
                        logger.error(f"User info request failed: {response.status} - {error_text}")
                        return None
                        
        except Exception as e:
            logger.error(f"Error getting user info: {e}")
            return None
            
    async def get_roblox_user_details(self, roblox_id: int) -> Optional[Dict[str, Any]]:
        """Get detailed user information from Roblox API"""
        try:
            url = f"{Config.ROBLOX_USER_API_URL}/{roblox_id}"
            
            async with aiohttp.ClientSession() as session:
                async with session.get(url) as response:
                    if response.status == 200:
                        user_data = await response.json()
                        return user_data
                    else:
                        logger.error(f"Failed to get Roblox user details: {response.status}")
                        return None
                        
        except Exception as e:
            logger.error(f"Error getting Roblox user details: {e}")
            return None
            
    @staticmethod
    def generate_state() -> str:
        """Generate a secure random state parameter"""
        return secrets.token_urlsafe(32)
