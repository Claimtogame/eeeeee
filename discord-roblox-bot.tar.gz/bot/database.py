import sqlite3
import asyncio
import logging
from typing import Optional, Dict, Any
import aiosqlite

logger = logging.getLogger(__name__)

class Database:
    def __init__(self, db_path: str = 'bot_data.db'):
        self.db_path = db_path
        
    async def initialize(self):
        """Initialize database and create tables"""
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute('''
                CREATE TABLE IF NOT EXISTS user_verifications (
                    discord_id INTEGER PRIMARY KEY,
                    roblox_id INTEGER NOT NULL,
                    roblox_username TEXT NOT NULL,
                    verified_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    verification_method TEXT DEFAULT 'oauth'
                )
            ''')
            
            await db.execute('''
                CREATE TABLE IF NOT EXISTS verification_sessions (
                    session_id TEXT PRIMARY KEY,
                    discord_id INTEGER NOT NULL,
                    state TEXT NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    expires_at TIMESTAMP NOT NULL
                )
            ''')
            
            await db.execute('''
                CREATE INDEX IF NOT EXISTS idx_discord_id ON user_verifications(discord_id)
            ''')
            
            await db.execute('''
                CREATE INDEX IF NOT EXISTS idx_roblox_id ON user_verifications(roblox_id)
            ''')
            
            await db.commit()
            
        logger.info("Database initialized successfully")
        
    async def add_verification(self, discord_id: int, roblox_id: int, roblox_username: str, method: str = 'oauth') -> bool:
        """Add or update user verification"""
        try:
            async with aiosqlite.connect(self.db_path) as db:
                await db.execute('''
                    INSERT OR REPLACE INTO user_verifications 
                    (discord_id, roblox_id, roblox_username, verification_method)
                    VALUES (?, ?, ?, ?)
                ''', (discord_id, roblox_id, roblox_username, method))
                
                await db.commit()
                
            logger.info(f"Added verification: Discord {discord_id} -> Roblox {roblox_id} ({roblox_username})")
            return True
            
        except Exception as e:
            logger.error(f"Failed to add verification: {e}")
            return False
            
    async def remove_verification(self, discord_id: int) -> bool:
        """Remove user verification"""
        try:
            async with aiosqlite.connect(self.db_path) as db:
                cursor = await db.execute(
                    'DELETE FROM user_verifications WHERE discord_id = ?',
                    (discord_id,)
                )
                
                await db.commit()
                
                if cursor.rowcount > 0:
                    logger.info(f"Removed verification for Discord user {discord_id}")
                    return True
                else:
                    logger.info(f"No verification found for Discord user {discord_id}")
                    return False
                    
        except Exception as e:
            logger.error(f"Failed to remove verification: {e}")
            return False
            
    async def get_verification_by_discord(self, discord_id: int) -> Optional[Dict[str, Any]]:
        """Get verification data by Discord ID"""
        try:
            async with aiosqlite.connect(self.db_path) as db:
                db.row_factory = aiosqlite.Row
                cursor = await db.execute(
                    'SELECT * FROM user_verifications WHERE discord_id = ?',
                    (discord_id,)
                )
                
                row = await cursor.fetchone()
                
                if row:
                    return dict(row)
                return None
                
        except Exception as e:
            logger.error(f"Failed to get verification by Discord ID: {e}")
            return None
            
    async def get_verification_by_roblox(self, roblox_id: int) -> Optional[Dict[str, Any]]:
        """Get verification data by Roblox ID"""
        try:
            async with aiosqlite.connect(self.db_path) as db:
                db.row_factory = aiosqlite.Row
                cursor = await db.execute(
                    'SELECT * FROM user_verifications WHERE roblox_id = ?',
                    (roblox_id,)
                )
                
                row = await cursor.fetchone()
                
                if row:
                    return dict(row)
                return None
                
        except Exception as e:
            logger.error(f"Failed to get verification by Roblox ID: {e}")
            return None
            
    async def create_verification_session(self, session_id: str, discord_id: int, state: str, expires_at: str) -> bool:
        """Create a verification session"""
        try:
            async with aiosqlite.connect(self.db_path) as db:
                await db.execute('''
                    INSERT INTO verification_sessions 
                    (session_id, discord_id, state, expires_at)
                    VALUES (?, ?, ?, ?)
                ''', (session_id, discord_id, state, expires_at))
                
                await db.commit()
                
            return True
            
        except Exception as e:
            logger.error(f"Failed to create verification session: {e}")
            return False
            
    async def get_verification_session(self, session_id: str) -> Optional[Dict[str, Any]]:
        """Get verification session by session ID"""
        try:
            async with aiosqlite.connect(self.db_path) as db:
                db.row_factory = aiosqlite.Row
                cursor = await db.execute(
                    'SELECT * FROM verification_sessions WHERE session_id = ?',
                    (session_id,)
                )
                
                row = await cursor.fetchone()
                
                if row:
                    return dict(row)
                return None
                
        except Exception as e:
            logger.error(f"Failed to get verification session: {e}")
            return None
            
    async def delete_verification_session(self, session_id: str) -> bool:
        """Delete verification session"""
        try:
            async with aiosqlite.connect(self.db_path) as db:
                await db.execute(
                    'DELETE FROM verification_sessions WHERE session_id = ?',
                    (session_id,)
                )
                
                await db.commit()
                
            return True
            
        except Exception as e:
            logger.error(f"Failed to delete verification session: {e}")
            return False
            
    async def cleanup_expired_sessions(self):
        """Clean up expired verification sessions"""
        try:
            async with aiosqlite.connect(self.db_path) as db:
                await db.execute(
                    'DELETE FROM verification_sessions WHERE expires_at < datetime("now")'
                )
                
                await db.commit()
                
        except Exception as e:
            logger.error(f"Failed to cleanup expired sessions: {e}")
