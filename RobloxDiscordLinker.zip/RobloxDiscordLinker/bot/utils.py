import discord
from discord.ext import commands
import logging
from typing import Optional, List
from config import Config

logger = logging.getLogger(__name__)

class PermissionUtils:
    @staticmethod
    def has_admin_role(member: discord.Member) -> bool:
        """Check if member has admin role"""
        admin_roles = [role.name for role in member.roles if role.name in Config.ADMIN_ROLE_NAMES]
        return len(admin_roles) > 0 or member.guild_permissions.administrator
        
    @staticmethod
    def has_manage_roles_permission(member: discord.Member) -> bool:
        """Check if member can manage roles"""
        return member.guild_permissions.manage_roles or member.guild_permissions.administrator

class RoleUtils:
    @staticmethod
    async def get_verified_role(guild: discord.Guild) -> Optional[discord.Role]:
        """Get the verified role from guild"""
        role = discord.utils.get(guild.roles, name=Config.VERIFIED_ROLE_NAME)
        
        if not role:
            logger.warning(f"Verified role '{Config.VERIFIED_ROLE_NAME}' not found in guild {guild.name}")
            
        return role
        
    @staticmethod
    async def create_verified_role(guild: discord.Guild) -> Optional[discord.Role]:
        """Create verified role if it doesn't exist"""
        try:
            role = await guild.create_role(
                name=Config.VERIFIED_ROLE_NAME,
                color=discord.Color.green(),
                reason="Roblox verification role"
            )
            
            logger.info(f"Created verified role '{Config.VERIFIED_ROLE_NAME}' in guild {guild.name}")
            return role
            
        except discord.Forbidden:
            logger.error(f"No permission to create role in guild {guild.name}")
            return None
        except Exception as e:
            logger.error(f"Error creating verified role: {e}")
            return None
            
    @staticmethod
    async def assign_verified_role(member: discord.Member) -> bool:
        """Assign verified role to member"""
        try:
            role = await RoleUtils.get_verified_role(member.guild)
            
            if not role:
                role = await RoleUtils.create_verified_role(member.guild)
                
            if not role:
                logger.error(f"Could not get or create verified role for {member.guild.name}")
                return False
                
            if role in member.roles:
                logger.info(f"Member {member.display_name} already has verified role")
                return True
                
            await member.add_roles(role, reason="Roblox account verified")
            logger.info(f"Assigned verified role to {member.display_name}")
            return True
            
        except discord.Forbidden:
            logger.error(f"No permission to assign role to {member.display_name}")
            return False
        except Exception as e:
            logger.error(f"Error assigning verified role: {e}")
            return False
            
    @staticmethod
    async def remove_verified_role(member: discord.Member) -> bool:
        """Remove verified role from member"""
        try:
            role = await RoleUtils.get_verified_role(member.guild)
            
            if not role:
                logger.info(f"Verified role not found in guild {member.guild.name}")
                return True
                
            if role not in member.roles:
                logger.info(f"Member {member.display_name} doesn't have verified role")
                return True
                
            await member.remove_roles(role, reason="Roblox verification removed")
            logger.info(f"Removed verified role from {member.display_name}")
            return True
            
        except discord.Forbidden:
            logger.error(f"No permission to remove role from {member.display_name}")
            return False
        except Exception as e:
            logger.error(f"Error removing verified role: {e}")
            return False

class EmbedUtils:
    @staticmethod
    def create_success_embed(title: str, description: str) -> discord.Embed:
        """Create success embed"""
        embed = discord.Embed(
            title=title,
            description=description,
            color=discord.Color.green()
        )
        return embed
        
    @staticmethod
    def create_error_embed(title: str, description: str) -> discord.Embed:
        """Create error embed"""
        embed = discord.Embed(
            title=title,
            description=description,
            color=discord.Color.red()
        )
        return embed
        
    @staticmethod
    def create_info_embed(title: str, description: str) -> discord.Embed:
        """Create info embed"""
        embed = discord.Embed(
            title=title,
            description=description,
            color=discord.Color.blue()
        )
        return embed
        
    @staticmethod
    def create_verification_embed(roblox_username: str, roblox_id: int) -> discord.Embed:
        """Create verification success embed"""
        embed = discord.Embed(
            title="✅ Account Verified!",
            description=f"Your Discord account has been successfully linked to your Roblox account.",
            color=discord.Color.green()
        )
        
        embed.add_field(
            name="Roblox Username",
            value=roblox_username,
            inline=True
        )
        
        embed.add_field(
            name="Roblox ID",
            value=str(roblox_id),
            inline=True
        )
        
        embed.set_footer(text="You have been assigned the verified role!")
        
        return embed
        
    @staticmethod
    def create_user_info_embed(discord_user: discord.User, roblox_username: str, roblox_id: int, verification_method: str) -> discord.Embed:
        """Create user info embed for whois command"""
        embed = discord.Embed(
            title="🔍 User Information",
            color=discord.Color.blue()
        )
        
        embed.add_field(
            name="Discord User",
            value=f"{discord_user.display_name} ({discord_user.mention})",
            inline=False
        )
        
        embed.add_field(
            name="Roblox Username",
            value=roblox_username,
            inline=True
        )
        
        embed.add_field(
            name="Roblox ID",
            value=str(roblox_id),
            inline=True
        )
        
        embed.add_field(
            name="Verification Method",
            value=verification_method.title(),
            inline=True
        )
        
        if discord_user.avatar:
            embed.set_thumbnail(url=discord_user.avatar.url)
            
        return embed

def is_valid_roblox_id(roblox_id: str) -> bool:
    """Validate Roblox ID format"""
    try:
        id_int = int(roblox_id)
        return id_int > 0
    except ValueError:
        return False

def is_valid_discord_id(discord_id: str) -> bool:
    """Validate Discord ID format"""
    try:
        id_int = int(discord_id)
        return id_int > 0
    except ValueError:
        return False
