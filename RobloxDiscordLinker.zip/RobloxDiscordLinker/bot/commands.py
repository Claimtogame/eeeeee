import discord
from discord.ext import commands
from discord import app_commands
import logging
import secrets
from datetime import datetime, timedelta
from typing import Optional

from bot.utils import PermissionUtils, RoleUtils, EmbedUtils, is_valid_roblox_id, is_valid_discord_id
from bot.oauth import RobloxOAuth
from config import Config

logger = logging.getLogger(__name__)

async def setup_commands(bot: commands.Bot):
    """Setup all slash commands"""
    
    @bot.tree.command(name="verify", description="Verify your Roblox account using OAuth 2.0")
    async def verify_command(interaction: discord.Interaction):
        """Start Roblox OAuth verification process"""
        try:
            # Respond immediately to avoid timeout
            await interaction.response.defer(ephemeral=True)
            
            # Check if user is already verified
            existing_verification = await bot.db.get_verification_by_discord(interaction.user.id)
            if existing_verification:
                embed = EmbedUtils.create_error_embed(
                    "Already Verified",
                    f"Your account is already linked to Roblox user: **{existing_verification['roblox_username']}** (ID: {existing_verification['roblox_id']})"
                )
                await interaction.followup.send(embed=embed, ephemeral=True)
                return
            
            # Generate verification session
            session_id = secrets.token_urlsafe(32)
            state = RobloxOAuth.generate_state()
            expires_at = (datetime.now() + timedelta(minutes=10)).isoformat()
            
            # Store session in database
            success = await bot.db.create_verification_session(
                session_id, interaction.user.id, state, expires_at
            )
            
            if not success:
                embed = EmbedUtils.create_error_embed(
                    "Session Error",
                    "Failed to create verification session. Please try again."
                )
                await interaction.followup.send(embed=embed, ephemeral=True)
                return
            
            # Generate OAuth URL
            oauth = RobloxOAuth()
            oauth_url = oauth.generate_oauth_url(state)
            
            # Create verification embed with button
            embed = discord.Embed(
                title="🔗 Roblox Account Verification",
                description="Click the button below to verify your Roblox account using OAuth 2.0.",
                color=discord.Color.blue()
            )
            
            embed.add_field(
                name="What happens next?",
                value="1. Click 'Verify with Roblox'\n2. Log into your Roblox account\n3. Authorize the application\n4. Get automatically verified!",
                inline=False
            )
            
            embed.set_footer(text="This verification link expires in 10 minutes.")
            
            # Create view with verification button
            view = VerificationView(oauth_url, session_id)
            
            await interaction.followup.send(embed=embed, view=view, ephemeral=True)
            
        except Exception as e:
            logger.error(f"Error in verify command: {e}")
            embed = EmbedUtils.create_error_embed(
                "Verification Error",
                "An error occurred while starting verification. Please try again."
            )
            try:
                await interaction.followup.send(embed=embed, ephemeral=True)
            except:
                # If followup fails, try original response
                await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @bot.tree.command(name="admin-verify", description="Admin: Manually link a Roblox account to a Discord user")
    @app_commands.describe(
        discord_user="The Discord user to verify",
        roblox_id="The Roblox user ID to link"
    )
    async def admin_verify_command(interaction: discord.Interaction, discord_user: discord.Member, roblox_id: str):
        """Admin command to manually verify a user"""
        try:
            # Check admin permissions
            if not PermissionUtils.has_admin_role(interaction.user):
                embed = EmbedUtils.create_error_embed(
                    "Permission Denied",
                    "You don't have permission to use this command."
                )
                await interaction.response.send_message(embed=embed, ephemeral=True)
                return
            
            # Validate Roblox ID
            if not is_valid_roblox_id(roblox_id):
                embed = EmbedUtils.create_error_embed(
                    "Invalid Roblox ID",
                    "Please provide a valid Roblox user ID."
                )
                await interaction.response.send_message(embed=embed, ephemeral=True)
                return
            
            roblox_id_int = int(roblox_id)
            
            # Check if Discord user is already verified
            existing_verification = await bot.db.get_verification_by_discord(discord_user.id)
            if existing_verification:
                embed = EmbedUtils.create_error_embed(
                    "User Already Verified",
                    f"{discord_user.mention} is already linked to Roblox user: **{existing_verification['roblox_username']}** (ID: {existing_verification['roblox_id']})"
                )
                await interaction.response.send_message(embed=embed, ephemeral=True)
                return
            
            # Check if Roblox account is already linked
            existing_roblox = await bot.db.get_verification_by_roblox(roblox_id_int)
            if existing_roblox:
                embed = EmbedUtils.create_error_embed(
                    "Roblox Account Already Linked",
                    f"Roblox ID {roblox_id} is already linked to another Discord account."
                )
                await interaction.response.send_message(embed=embed, ephemeral=True)
                return
            
            # Get Roblox user details
            oauth = RobloxOAuth()
            roblox_details = await oauth.get_roblox_user_details(roblox_id_int)
            
            if not roblox_details:
                embed = EmbedUtils.create_error_embed(
                    "Invalid Roblox User",
                    f"Could not find Roblox user with ID: {roblox_id}"
                )
                await interaction.response.send_message(embed=embed, ephemeral=True)
                return
            
            roblox_username = roblox_details.get('name', f'User{roblox_id}')
            
            # Add verification to database
            success = await bot.db.add_verification(
                discord_user.id, roblox_id_int, roblox_username, 'admin'
            )
            
            if not success:
                embed = EmbedUtils.create_error_embed(
                    "Database Error",
                    "Failed to save verification to database."
                )
                await interaction.response.send_message(embed=embed, ephemeral=True)
                return
            
            # Assign verified role
            role_success = await RoleUtils.assign_verified_role(discord_user)
            
            # Create success embed
            embed = EmbedUtils.create_success_embed(
                "✅ Manual Verification Complete",
                f"Successfully linked {discord_user.mention} to Roblox account **{roblox_username}** (ID: {roblox_id})"
            )
            
            if not role_success:
                embed.add_field(
                    name="⚠️ Role Assignment Failed",
                    value="Verification saved but couldn't assign role. Check bot permissions.",
                    inline=False
                )
            
            embed.set_footer(text=f"Verified by {interaction.user.display_name}")
            
            await interaction.response.send_message(embed=embed)
            
        except Exception as e:
            logger.error(f"Error in admin-verify command: {e}")
            embed = EmbedUtils.create_error_embed(
                "Command Error",
                "An error occurred while processing the verification."
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @bot.tree.command(name="admin-remove-rblx", description="Admin: Remove Roblox account link from a Discord user")
    @app_commands.describe(
        discord_user="The Discord user to remove verification from"
    )
    async def admin_remove_command(interaction: discord.Interaction, discord_user: discord.Member):
        """Admin command to remove verification"""
        try:
            # Check admin permissions
            if not PermissionUtils.has_admin_role(interaction.user):
                embed = EmbedUtils.create_error_embed(
                    "Permission Denied",
                    "You don't have permission to use this command."
                )
                await interaction.response.send_message(embed=embed, ephemeral=True)
                return
            
            # Check if user is verified
            existing_verification = await bot.db.get_verification_by_discord(discord_user.id)
            if not existing_verification:
                embed = EmbedUtils.create_error_embed(
                    "User Not Verified",
                    f"{discord_user.mention} is not currently verified."
                )
                await interaction.response.send_message(embed=embed, ephemeral=True)
                return
            
            roblox_username = existing_verification['roblox_username']
            roblox_id = existing_verification['roblox_id']
            
            # Remove verification from database
            success = await bot.db.remove_verification(discord_user.id)
            
            if not success:
                embed = EmbedUtils.create_error_embed(
                    "Database Error",
                    "Failed to remove verification from database."
                )
                await interaction.response.send_message(embed=embed, ephemeral=True)
                return
            
            # Remove verified role
            role_success = await RoleUtils.remove_verified_role(discord_user)
            
            # Create success embed
            embed = EmbedUtils.create_success_embed(
                "✅ Verification Removed",
                f"Successfully removed Roblox account link from {discord_user.mention}"
            )
            
            embed.add_field(
                name="Removed Link",
                value=f"**{roblox_username}** (ID: {roblox_id})",
                inline=False
            )
            
            if not role_success:
                embed.add_field(
                    name="⚠️ Role Removal Failed",
                    value="Verification removed but couldn't remove role. Check bot permissions.",
                    inline=False
                )
            
            embed.set_footer(text=f"Removed by {interaction.user.display_name}")
            
            await interaction.response.send_message(embed=embed)
            
        except Exception as e:
            logger.error(f"Error in admin-remove-rblx command: {e}")
            embed = EmbedUtils.create_error_embed(
                "Command Error",
                "An error occurred while removing the verification."
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @bot.tree.command(name="roblox-whois", description="Look up linked Roblox account for a Discord user")
    @app_commands.describe(
        discord_user="The Discord user to look up"
    )
    async def whois_command(interaction: discord.Interaction, discord_user: discord.Member):
        """Look up Roblox account for Discord user"""
        try:
            # Get verification data
            verification = await bot.db.get_verification_by_discord(discord_user.id)
            
            if not verification:
                embed = EmbedUtils.create_error_embed(
                    "User Not Verified",
                    f"{discord_user.mention} has not verified their Roblox account."
                )
                await interaction.response.send_message(embed=embed, ephemeral=True)
                return
            
            # Create user info embed
            embed = EmbedUtils.create_user_info_embed(
                discord_user,
                verification['roblox_username'],
                verification['roblox_id'],
                verification['verification_method']
            )
            
            embed.add_field(
                name="Verified Date",
                value=f"<t:{int(datetime.fromisoformat(verification['verified_at']).timestamp())}:R>",
                inline=True
            )
            
            await interaction.response.send_message(embed=embed)
            
        except Exception as e:
            logger.error(f"Error in roblox-whois command: {e}")
            embed = EmbedUtils.create_error_embed(
                "Command Error",
                "An error occurred while looking up the user."
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)

class VerificationView(discord.ui.View):
    def __init__(self, oauth_url: str, session_id: str):
        super().__init__(timeout=600)  # 10 minute timeout
        self.oauth_url = oauth_url
        self.session_id = session_id
        
    @discord.ui.button(label='Verify with Roblox', style=discord.ButtonStyle.primary, emoji='🔗')
    async def verify_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        # Create verification URL with session tracking
        verification_url = f"{Config.ROBLOX_REDIRECT_URI}?session={self.session_id}&oauth_url={self.oauth_url}"
        
        embed = discord.Embed(
            title="🔗 Continue Verification",
            description=f"[Click here to verify with Roblox]({self.oauth_url})",
            color=discord.Color.blue()
        )
        
        embed.add_field(
            name="Instructions",
            value="1. Click the link above\n2. Log into Roblox\n3. Authorize the application\n4. Return to Discord",
            inline=False
        )
        
        embed.set_footer(text="Verification expires in 10 minutes")
        
        await interaction.response.send_message(embed=embed, ephemeral=True)
