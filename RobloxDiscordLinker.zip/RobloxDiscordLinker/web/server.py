from aiohttp import web, ClientSession
import asyncio
import logging
import urllib.parse
from datetime import datetime, timedelta
from bot.oauth import RobloxOAuth
from bot.utils import RoleUtils, EmbedUtils
from config import Config

logger = logging.getLogger(__name__)

async def start_web_server(bot):
    """Start the web server for OAuth callbacks"""
    app = web.Application()
    
    # Store bot reference
    app['bot'] = bot
    
    # Setup routes
    app.router.add_get('/', index_handler)
    app.router.add_get('/callback', oauth_callback_handler)
    app.router.add_static('/static', 'web/static')
    
    # Start server
    runner = web.AppRunner(app)
    await runner.setup()
    
    site = web.TCPSite(runner, Config.WEB_HOST, Config.WEB_PORT)
    await site.start()
    
    logger.info(f"Web server started on {Config.WEB_HOST}:{Config.WEB_PORT}")

async def index_handler(request):
    """Serve the main verification page"""
    with open('web/templates/verify.html', 'r') as f:
        html_content = f.read()
    
    return web.Response(text=html_content, content_type='text/html')

async def oauth_callback_handler(request):
    """Handle OAuth callback from Roblox"""
    try:
        bot = request.app['bot']
        
        # Get parameters from callback
        code = request.query.get('code')
        state = request.query.get('state')
        error = request.query.get('error')
        
        if error:
            logger.error(f"OAuth error: {error}")
            return web.Response(
                text=create_error_page("Authorization was denied or failed. Please try again."),
                content_type='text/html'
            )
        
        if not code or not state:
            logger.error("Missing code or state in OAuth callback")
            return web.Response(
                text=create_error_page("Invalid callback parameters. Please try again."),
                content_type='text/html'
            )
        
        # Find verification session by state
        session = None
        async with bot.db.aiosqlite.connect(bot.db.db_path) as db:
            cursor = await db.execute(
                'SELECT * FROM verification_sessions WHERE state = ? AND expires_at > datetime("now")',
                (state,)
            )
            row = await cursor.fetchone()
            if row:
                columns = [description[0] for description in cursor.description]
                session = dict(zip(columns, row))
        
        if not session:
            logger.error(f"No valid session found for state: {state}")
            return web.Response(
                text=create_error_page("Verification session expired or invalid. Please start over."),
                content_type='text/html'
            )
        
        discord_id = session['discord_id']
        
        # Check if user is already verified
        existing_verification = await bot.db.get_verification_by_discord(discord_id)
        if existing_verification:
            await bot.db.delete_verification_session(session['session_id'])
            return web.Response(
                text=create_error_page("Your account is already verified."),
                content_type='text/html'
            )
        
        # Exchange code for token
        oauth = RobloxOAuth()
        token_data = await oauth.exchange_code_for_token(code)
        
        if not token_data:
            logger.error("Failed to exchange code for token")
            return web.Response(
                text=create_error_page("Failed to authenticate with Roblox. Please try again."),
                content_type='text/html'
            )
        
        access_token = token_data.get('access_token')
        if not access_token:
            logger.error("No access token in response")
            return web.Response(
                text=create_error_page("Authentication failed. Please try again."),
                content_type='text/html'
            )
        
        # Get user info
        user_info = await oauth.get_user_info(access_token)
        if not user_info:
            logger.error("Failed to get user info")
            return web.Response(
                text=create_error_page("Failed to get user information. Please try again."),
                content_type='text/html'
            )
        
        roblox_id = int(user_info.get('sub'))
        roblox_username = user_info.get('preferred_username', f'User{roblox_id}')
        
        # Check if Roblox account is already linked
        existing_roblox = await bot.db.get_verification_by_roblox(roblox_id)
        if existing_roblox:
            await bot.db.delete_verification_session(session['session_id'])
            return web.Response(
                text=create_error_page("This Roblox account is already linked to another Discord account."),
                content_type='text/html'
            )
        
        # Save verification
        success = await bot.db.add_verification(discord_id, roblox_id, roblox_username, 'oauth')
        
        if not success:
            logger.error("Failed to save verification to database")
            return web.Response(
                text=create_error_page("Failed to save verification. Please try again."),
                content_type='text/html'
            )
        
        # Clean up session
        await bot.db.delete_verification_session(session['session_id'])
        
        # Assign verified role
        try:
            # Get Discord user
            discord_user = bot.get_user(discord_id)
            if discord_user:
                # Find guild where user is member
                for guild in bot.guilds:
                    member = guild.get_member(discord_id)
                    if member:
                        role_success = await RoleUtils.assign_verified_role(member)
                        if role_success:
                            logger.info(f"Assigned verified role to {member.display_name} in {guild.name}")
                        break
        except Exception as e:
            logger.error(f"Error assigning role: {e}")
        
        # Send success notification to user
        try:
            discord_user = bot.get_user(discord_id)
            if discord_user:
                embed = EmbedUtils.create_verification_embed(roblox_username, roblox_id)
                await discord_user.send(embed=embed)
        except Exception as e:
            logger.error(f"Failed to send DM to user: {e}")
        
        logger.info(f"Successfully verified Discord user {discord_id} with Roblox {roblox_username} ({roblox_id})")
        
        return web.Response(
            text=create_success_page(roblox_username),
            content_type='text/html'
        )
        
    except Exception as e:
        logger.error(f"Error in OAuth callback: {e}")
        return web.Response(
            text=create_error_page("An unexpected error occurred. Please try again."),
            content_type='text/html'
        )

def create_success_page(roblox_username: str) -> str:
    """Create success page HTML"""
    return f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Verification Successful</title>
        <link rel="stylesheet" href="/static/style.css">
    </head>
    <body>
        <div class="container">
            <div class="success-box">
                <h1>✅ Verification Successful!</h1>
                <p>Your Discord account has been successfully linked to your Roblox account: <strong>{roblox_username}</strong></p>
                <p>You have been assigned the verified role and can now close this page.</p>
                <button onclick="window.close()">Close Window</button>
            </div>
        </div>
    </body>
    </html>
    """

def create_error_page(error_message: str) -> str:
    """Create error page HTML"""
    return f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Verification Error</title>
        <link rel="stylesheet" href="/static/style.css">
    </head>
    <body>
        <div class="container">
            <div class="error-box">
                <h1>❌ Verification Failed</h1>
                <p>{error_message}</p>
                <p>Please return to Discord and try the verification process again.</p>
                <button onclick="window.close()">Close Window</button>
            </div>
        </div>
    </body>
    </html>
    """
